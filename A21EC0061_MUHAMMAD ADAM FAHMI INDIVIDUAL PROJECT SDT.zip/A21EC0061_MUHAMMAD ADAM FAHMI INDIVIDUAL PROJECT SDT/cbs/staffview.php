<?php

include 'cbssession.php';
if(!session_id()){
    session_start();
}

include 'headerstaff.php'; 
include ('dbconnect.php');

//retrieve new bookings
$sql = "SELECT * FROM tb_booking
        LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
        LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
        LEFT JOIN tb_user ON tb_booking.b_customer = tb_user.u_id
        WHERE b_status !='1'";

$result = mysqli_query($con,$sql);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="container">
<h3><br><br></h3>
    <div class="row">
        <div class="col-md-4 col-xxl-7">
            <h2 style="width: 343px;">Approved Booking List</h2>
        </div>
        <div class="col-md-4 d-flex justify-content-end align-self-start">
        <form method="GET" action="">
            <i class="fa fa-search"></i><input class="form-control me-sm-2" type="text" name="search" placeholder="Enter booking ID">
        </form>
        </div>
    </div>
<br><br>

<?php
if(isset($_GET['search'])) {
    $search = $_GET['search'];
    $sql = "SELECT * FROM tb_booking
        LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
        LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
        LEFT JOIN tb_user ON tb_booking.b_customer = tb_user.u_id
        WHERE b_status !='1' AND b_id = '$search'";
    $result = mysqli_query($con,$sql);
} else {
    $sql = "SELECT * FROM tb_booking
        LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
        LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
        LEFT JOIN tb_user ON tb_booking.b_customer = tb_user.u_id
        WHERE b_status !='1'";
    $result = mysqli_query($con,$sql);
}
?>

    <table class="table table-hover">
    <thead>
        <tr>
        <th scope="col">Booking ID</th>
        <th scope="col">Customer</th>
        <th scope="col">Model</th>
        <th scope="col">Pickup date</th>
        <th scope="col">Return date</th>
        <th scope="col">Total price</th>
        <th scope="col">Status</th>
        <th scope="col">Operation</th>
        </tr>
    </thead>
    <tbody>

<?php
    while($row = mysqli_fetch_array($result)){
        echo '<tr>';
        echo "<td>".$row['b_id']."</td>";
        echo "<td>".$row['u_name']."</td>";
        echo "<td>".$row['v_model']."</td>";
        echo "<td>".$row['b_pickupdate']."</td>";
        echo "<td>".$row['b_returndate']."</td>";
        echo "<td>".$row['b_totalprice']."</td>";
        echo "<td>".$row['s_desc']."</td>"; //letak non tb_booking variable by JOIN ON syntax
        echo "<td>";
            echo"<a href= 'staffapproval.php?id=" .$row['b_id']." 'class= 'btn btn-warning'>Modify</a>";
        echo "</td>";
        echo '</tr>';
    }
?>

    </tbody>
    </table>
</div>


<?php include 'footer.php'; ?>


