<?php
include('dbconnect.php');
$id = $_POST['id'];

$delete_query = "DELETE FROM tb_vehicle WHERE v_reg = '$id'";
$run_query = mysqli_query($con,$delete_query);

if($run_query){

    header('location:dashboard.php');
}
?>