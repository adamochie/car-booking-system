<?php
include ('dbconnect.php');
include 'cbssession.php';
if(!session_id()){
    session_start();
}

include 'headercustomer.php';

$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user 
        WHERE u_id='$uid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

?>

<section class="py-5 mt-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-8 col-xl-6 text-center mx-auto">
                <h2 class="display-6 fw-bold mb-4"><br><br><br> Welcome back <?php echo $row['u_name'] ?>!</h2>
                <p class="text-muted">Please choose a car from the list below and fill in the Booking form</p>
            </div>
            <div class="col-5">
            <form method="POST" action="customerprocess.php">
            <fieldset>

                <div class="form-group">
                <label for="exampleSelect1" class="form-label mt-4">Select Vehicle</label>
                <?php
                    $sql="SELECT * FROM tb_vehicle";
                    $result = mysqli_query($con,$sql);

                    echo '<select class = "form-select" name="fvec" id="exampleSelect1" >';
                    while($row= mysqli_fetch_array($result)){
                        echo "<option value = '".$row['v_reg']."'>" .$row['v_model']. "</option>"; //KITA AMIK V_REG COZ UNIQUE 
                    }

                    echo '</select>';
                ?>

                </div>

                <div class="form-group">
                <label class="form-label mt-4">Pick up date</label>
                <input type="date" name="fpdate" class="form-control" value="<?php 
                date_default_timezone_set('Asia/Kuala_Lumpur');
                echo date('Y-m-d'); ?>" placeholder=" " required>
                </div>

                <div class="form-group">
                <label class="form-label mt-4">Return date</label>
                <input type="date" name="frdate" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" required>
                </div>

            </fieldset>

            <br>

            <fieldset>
                    <button type="submit" style="background-color: orange; color: black;" class="btn btn-primary">Book now</button>
                    <button type="reset" class="btn btn-outline-light">Reset</button>
            </fieldset>
            </form>
            </div>
        </div>
    </div>
</section>

<?php 
$sequel = "SELECT * FROM tb_vehicle ORDER BY v_price DESC";
$r = mysqli_query($con,$sequel)
?>

<div class="container">
<div class="col-md-12"> <h2>Ready-to-rent cars</h2><br>
<div class="row">
<?php
while ($row = mysqli_fetch_array($r)) {
    echo '<div class="card bg-secondary mb-3" style="max-width: 20rem;">';
    echo '<div class="border">';
    echo '<div class="wrap">';
    echo '<div class="product-wrap"><div><img class="img-thumbnail" src="media/'.$row['v_media'].'" width="" height="150"></div></div>';
    echo '<div class="loop-action"><a class="add-to-cart" href>'.$row['v_type'] .'</a></div>
                </div>';
    echo '<div class="product-info">';
    echo '<div class="stars"></div>';
    echo '<h3 class="product-title">'. $row['v_model'] . ' (' . $row['v_year'] . ')</h3>';
    $formatted_price = number_format($row['v_price'], 2, '.', '');
    echo '<div class="price">RM ' . $formatted_price . '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}
?>    
</div>
</div>


<br><br><br><br>
<?php include 'footer.php'; ?>