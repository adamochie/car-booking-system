<?php
include ('dbconnect.php');
include 'cbssession.php';
if(!session_id()){
    session_start();
}

include 'headerstaff.php'; 


$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user 
        WHERE u_id='$uid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

$query = "SELECT * FROM tb_booking
        LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
        LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
        LEFT JOIN tb_user ON tb_booking.b_customer = tb_user.u_id
        WHERE b_status ='1'
        ORDER BY b_id DESC
        LIMIT 4";
$res = mysqli_query($con,$query);
?>

<div class="container">
<section class="py-5 mt-5">
    <div class="container py-5">
        <div class="row">
            <div class="col-md-8 col-xl-5 text-center mx-auto">
                <h2 class="display-6 fw-bold mb-4"><br><br><br> Welcome back <?php echo $row['u_name'] ?>!</h2>
                <p class="text-muted">Admin page menu, Recieve List and Edit Vehicle Inventory </p>
            </div>
            <div class="col-5">
            <div class="card border-secondary">
            <div class="card-header">New Customer Booking List</div>
            <div class="card-body">
                <h4 class="card-title"></h4>
                <div class="container">
                <table class="table table-hover">
                    <thead>
                        <tr>
                        <th scope="col">Booking ID</th>
                        <th scope="col">Customer</th>
                        <th scope="col">Model</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        while($row = mysqli_fetch_array($res)){
                            echo '<tr>';
                            echo "<td>".$row['b_id']."</td>";
                            echo "<td>".$row['u_name']."</td>";
                            echo "<td>".$row['v_model']."</td>";
                            echo '</tr>';
                        }
                    ?>
                    </tbody>
                </table>
                <div class="alert alert-dismissible alert-primary">
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                <strong>New booking List to approve!</strong> <a href="staff.php" class="alert-link">approve full list</a>.
                </div>
                </div>
            </div>
            </div>
            </div>
        </div>
    </div>

<?php 
$sequel = "SELECT * FROM tb_vehicle";
$r = mysqli_query($con,$sequel)
?>

</section>
<div class="row">
    <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow border-start-primary py-2">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>total cars available</span></div>
                        <div class="text-dark fw-bold h5 mb-0"><span><?php echo mysqli_num_rows($r); ?></span></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-car-alt fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow border-start-success py-2">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>CUSTOMERS</span></div>
                        <div class="text-dark fw-bold h5 mb-0"><span>
    <?php 
        $sequel = "SELECT * FROM tb_user WHERE u_type = 1";
        $result = mysqli_query($con, $sequel);
        echo mysqli_num_rows($result);
    ?>
    
    </span></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-user fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow border-start-info py-2">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-info fw-bold text-xs mb-1"><span>BOOKINGS APPROVED</span></div>
                        <div class="row g-0 align-items-center">
                            <div class="col-auto">
                                <?php 
                                $total_bookings_query = "SELECT COUNT(*) as total_bookings FROM tb_booking";
                                $total_bookings_result = mysqli_query($con, $total_bookings_query);
                                $total_bookings = mysqli_fetch_assoc($total_bookings_result)['total_bookings'];
                                $approved_bookings_query = "SELECT COUNT(*) as approved_bookings FROM tb_booking WHERE b_status = 2";
                                $approved_bookings_result = mysqli_query($con, $approved_bookings_query);
                                $approved_bookings = mysqli_fetch_assoc($approved_bookings_result)['approved_bookings'];

                                $percentage_approved_bookings = number_format(($approved_bookings / $total_bookings) * 100, 2);
                                ?>
                                <div class="text-dark fw-bold h5 mb-0 me-3"><span><?php echo $percentage_approved_bookings; ?>%</span></div>
                            </div>
                            <div class="col">
                            <div class="progress progress-sm">

                            <div class="progress-bar bg-info" aria-valuenow="<?php echo $percentage_approved_bookings; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $percentage_approved_bookings; ?>%;"><span class="visually-hidden"><?php echo $percentage_approved_bookings; ?>%</span></div>
                            </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-auto"><i class="fas fa-clipboard-list fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-4">
        <div class="card shadow border-start-warning py-2">
            <div class="card-body">
                <div class="row align-items-center no-gutters">
                    <div class="col me-2">
                        <div class="text-uppercase text-danger fw-bold text-xs mb-1"><span>Pending APPROVAL</span></div>
                        <div class="text-dark fw-bold h5 mb-0"><span>
    <?php 
        $sequel = "SELECT * FROM tb_booking WHERE b_status = 1";
        $result = mysqli_query($con, $sequel);
        echo mysqli_num_rows($result);
    ?>
    </span></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-comments fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>

<br><br>

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<div>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
            </div>
            <div class="col-md-4 d-flex justify-content-end align-self-start"></div>
            <div class="col-md-4 col-xxl-4 d-flex justify-content-center align-items-center">
                
            <a href="add_vehicle.php" class="btn btn-outline-primary d-flex align-items-center align-self-center" style="height: 38px;background-color: rgb(21,221,4);">Add Vehicle <i class="fa fa-plus-circle"></i></a></div>
        </div>
        <br>

        <div class="row">
            <div class="col-md-12">
                <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>Vehicle List</th>
                            <th>Registration Number</th>
                            <th>Car Type</th>
                            <th>Model</th>
                            <th>Year</th>
                            <th>Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php
    while($row = mysqli_fetch_array($r)){
        echo "<tr>";
        echo '<td><div><img class="img-thumbnail" src="media/'.$row['v_media'].'" width="350" height="350"></div></td>';
        echo "<td>".$row['v_reg']."</td>";
        echo "<td>".$row['v_type']."</td>";
        echo "<td>".$row['v_model']."</td>";
        echo "<td>".$row['v_year']."</td>";
        echo "<td>".$row['v_price']."</td>";
        echo "<td>";
        echo '<form action="delete_vehicle.php" method="post">';
        echo '<input type="hidden" name="id" value="'.$row['v_reg'].'">';
        echo '<button type="submit" class="btn btn-outline-danger" onclick="return deleteCar()"><i class="far fa-trash-alt d-xl-flex justify-content-xl-center align-items-xl-center"></i></button>';
        echo '</form>';
        echo '<a href="update_vehicle.php?id='.$row['v_reg'].'" class="btn btn-outline-warning"><i class="fas fa-edit d-xl-flex justify-content-xl-center align-items-xl-center"></i></a>';
        echo "</td>";
        echo "</tr>";
    }
    ?>
</tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function deleteCar(){
  if(confirm("Click Confirm to delete vehicle?")){
    return true;
  }
  else{
    window.location.href = "dashboard.php";
    return false;
  }
}
</script>

<br><br><br>
<?php include 'footer.php'; ?>