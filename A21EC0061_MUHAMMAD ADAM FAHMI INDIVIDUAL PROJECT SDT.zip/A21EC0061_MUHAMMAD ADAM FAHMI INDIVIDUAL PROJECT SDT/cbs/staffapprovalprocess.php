<?php
include("dbconnect.php");
include 'cbssession.php';
if(!session_id()){
    session_start();
}

$fbid = $_POST['fbid'];
$fstatus = $_POST['fstatus'];

//update(insert) new booking to DB

$sql =" UPDATE tb_booking 
        SET b_status ='$fstatus'
        WHERE b_id='$fbid' ";

mysqli_query($con,$sql);
mysqli_close($con);

echo '<script>
alert("Status modified!");
window.location.href = "staffview.php";
</script>'

?>