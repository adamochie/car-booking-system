-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2023 at 02:48 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_carbooksys`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_booking`
--

CREATE TABLE `tb_booking` (
  `b_id` int(11) NOT NULL,
  `b_customer` varchar(15) NOT NULL,
  `b_vehicle` varchar(10) NOT NULL,
  `b_pickupdate` date NOT NULL,
  `b_returndate` date NOT NULL,
  `b_totalprice` float NOT NULL,
  `b_status` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_booking`
--

INSERT INTO `tb_booking` (`b_id`, `b_customer`, `b_vehicle`, `b_pickupdate`, `b_returndate`, `b_totalprice`, `b_status`) VALUES
(28, '011122100839', 'WAX 891', '2023-02-02', '2023-02-08', 1380, 2),
(29, '011122100839', 'WAX 891', '2023-02-10', '2023-02-13', 690, 1),
(30, '011122100839', 'WXU 911', '2023-02-09', '2023-02-10', 200.4, 4),
(31, '001122100839', 'WAX 891', '2023-02-24', '2023-02-25', 230, 1),
(32, '001122100839', 'DEZ 9', '2023-02-13', '2023-02-15', 201, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_status`
--

CREATE TABLE `tb_status` (
  `s_id` int(5) NOT NULL,
  `s_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_status`
--

INSERT INTO `tb_status` (`s_id`, `s_desc`) VALUES
(1, 'Recieve'),
(2, 'Approve'),
(3, 'Rejected'),
(4, 'Cancelled');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `u_id` varchar(15) NOT NULL COMMENT 'identity data',
  `u_pwd` varchar(200) NOT NULL,
  `u_name` varchar(200) NOT NULL,
  `u_address` varchar(200) DEFAULT NULL,
  `u_phone` varchar(20) NOT NULL,
  `u_lino` varchar(20) NOT NULL,
  `u_type` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`u_id`, `u_pwd`, `u_name`, `u_address`, `u_phone`, `u_lino`, `u_type`) VALUES
('001122100839', '$2y$10$7zqs.n.v9hBgvMLInkrp1.cWJiYq50wyz6W.WHaFhu/lACovgMtvy', 'Ronaldo Messi John', 'Simpang Empat Melaka', '0198765432', 'BLG991', '2'),
('011122100839', '$2y$10$urckGypjk05oGnfs6iDFau8GmVtdwgAYr5vaPkXScK71AtcJ2T/D2', 'Muhammad Fahmi Bin Zudin', 'Taman Puncak Jalil\r\n', '01128103703', 'VDY991', '2'),
('021122100839', '$2y$10$AmWtvlHcScqKSrlbo8HxguebRLzXbUPkBgu8R/dHSGvN7dCpoEdve', 'Kie Fung Ho', 'Skudai Lima', '0123456789', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tb_usertype`
--

CREATE TABLE `tb_usertype` (
  `ut_id` varchar(5) NOT NULL,
  `ut_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_usertype`
--

INSERT INTO `tb_usertype` (`ut_id`, `ut_desc`) VALUES
('1', 'admin'),
('2', 'customer');

-- --------------------------------------------------------

--
-- Table structure for table `tb_vehicle`
--

CREATE TABLE `tb_vehicle` (
  `v_media` longblob DEFAULT NULL,
  `v_reg` varchar(20) NOT NULL,
  `v_type` varchar(20) NOT NULL,
  `v_model` varchar(20) NOT NULL,
  `v_year` varchar(10) DEFAULT NULL,
  `v_price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_vehicle`
--

INSERT INTO `tb_vehicle` (`v_media`, `v_reg`, `v_type`, `v_model`, `v_year`, `v_price`) VALUES
(0x494d472d36336436643465633665633161392e36363339383231302e6a7067, 'DEZ 9', 'mayback', 'Perdana Wira', '2011', 100.5),
(0x494d472d36336436643533313462363262312e31303731363638342e706e67, 'WAX 891', 'Myvi', 'Myvi', '2019', 230),
(0x494d472d36336436643534303866653432342e33343137323239302e6a7067, 'WXU 911', 'hatchback', 'Perodua MYVI ', '2011', 200.4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_booking`
--
ALTER TABLE `tb_booking`
  ADD PRIMARY KEY (`b_id`),
  ADD KEY `b_customer` (`b_customer`),
  ADD KEY `b_vehicle` (`b_vehicle`),
  ADD KEY `b_status` (`b_status`);

--
-- Indexes for table `tb_status`
--
ALTER TABLE `tb_status`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`u_id`),
  ADD KEY `u_type` (`u_type`);

--
-- Indexes for table `tb_usertype`
--
ALTER TABLE `tb_usertype`
  ADD PRIMARY KEY (`ut_id`);

--
-- Indexes for table `tb_vehicle`
--
ALTER TABLE `tb_vehicle`
  ADD PRIMARY KEY (`v_reg`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_booking`
--
ALTER TABLE `tb_booking`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_booking`
--
ALTER TABLE `tb_booking`
  ADD CONSTRAINT `fk_vehicle_reg` FOREIGN KEY (`b_vehicle`) REFERENCES `tb_vehicle` (`v_reg`) ON DELETE CASCADE,
  ADD CONSTRAINT `tb_booking_ibfk_1` FOREIGN KEY (`b_customer`) REFERENCES `tb_user` (`u_id`),
  ADD CONSTRAINT `tb_booking_ibfk_2` FOREIGN KEY (`b_vehicle`) REFERENCES `tb_vehicle` (`v_reg`),
  ADD CONSTRAINT `tb_booking_ibfk_3` FOREIGN KEY (`b_status`) REFERENCES `tb_status` (`s_id`);

--
-- Constraints for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD CONSTRAINT `tb_user_ibfk_1` FOREIGN KEY (`u_type`) REFERENCES `tb_usertype` (`ut_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
