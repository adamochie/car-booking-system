<?php
include("dbconnect.php");

$fic = $_POST['fic'];
$fpwd = $_POST['fpwd'];
$fpwd2 = $_POST['fpwd2'];
$fname = $_POST['fname'];
$faddress = $_POST['faddress'];
$fcontact = $_POST['fcontact'];
$flino = $_POST['flino'];

if($fpwd == $fpwd2){
    $password_hash = password_hash($fpwd, PASSWORD_DEFAULT);
    $sql ="INSERT INTO tb_user(u_id,u_pwd,u_name,u_address,u_phone,u_lino,u_type) VALUE ('$fic','$password_hash','$fname','$faddress','$fcontact','$flino',2)";

    mysqli_query($con,$sql);
    mysqli_close($con);
    echo '<script>
                alert("Welcome to carsum.my! Please log in.");
                window.location.href = "login.php";
        </script>';
}
else{
    echo '<script>
                alert("The reenter password does not match! Please try again.");
                window.location.href = "register.php";
        </script>';
}

include 'headermain.php';
?>

<div class="container">
    <h3>registration successful. Please login to book</h3>
    <a href="login.php">Login page</a>
</div>

<?php include 'footer.php'; ?>