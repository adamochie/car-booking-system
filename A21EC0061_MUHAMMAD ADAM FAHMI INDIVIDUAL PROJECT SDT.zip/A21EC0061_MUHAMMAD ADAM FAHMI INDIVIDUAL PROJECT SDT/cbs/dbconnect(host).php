<?php
//Set DB parameterds
$servername = "localhost";
$username = "id19762002_muhammadadamfahmi";
$password = "Adam_11223344";
$dbname = "id19762002_db_carbooksys";

//Create DB Connection
$con = mysqli_connect($servername,$username,$password,$dbname);


//Check DB Connection

?>