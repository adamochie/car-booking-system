<?php 
include 'dbconnect.php';

include 'cbssession.php';
if (!session_id())
{
	session_start();
}

include 'headercustomer.php';


//get booking ID from URL
if(isset($_GET['id']))
{
	$bid = $_GET['id'];
}

$sql="SELECT * FROM tb_booking WHERE b_id = '$bid'";
$result=mysqli_query($con, $sql);
$row=mysqli_fetch_array($result); 

$sql1 = "SELECT * FROM tb_vehicle";
$result = mysqli_query($con,$sql1);

?>

<div class="container">

<div class="row">
    <div class="col-sm-7">
    <br><br>
	<legend>Car List</legend>
	<br>
    
	<?php

    while ($row1 = mysqli_fetch_array($result)) {
      echo '<div class="row">';
      echo '<div class="col-sm-6"><img class="img-thumbnail" id="v_media" src="media/'.$row1['v_media'].'"></div>';
      echo '<div class="col-sm-6">' . $row1['v_model'] . '<br>' . $row1['v_year'] . '<br>' . "RM " . $row1['v_price'] . '</div>';
      echo '</div>';
    }
    ?>

    </div>

  <div class="col-sm-4"><br><br>

		<form method="post" action="customermodifyprocess.php">
		  <fieldset>
		    <legend>Modify Form</legend>

		    <label for="exampleSelect1">Booking ID: <?php echo $bid ; ?></label>
		    <br><br>

		    <div class="form-group">
		      <label for="exampleSelect1">Select Vehicle</label>
					<?php
						$sqlv = "SELECT * FROM tb_vehicle";
						$resultv = mysqli_query($con, $sqlv);

						echo '<select class="form-select" name="fvec" id="exampleSelect1">';
						while($rowv = mysqli_fetch_array($resultv))
							{

								if($rowv['v_reg'] == $row['b_vehicle'])
								{
									echo"<option selected = 'selected' value = '".$rowv['v_reg']."'>".$rowv['v_model']."</option>";
								}
								else
								{
									echo"<option value = '".$rowv['v_reg']."'>".$rowv['v_model']."</option>";
								}
								
							}
						echo '</select>';
					?>

		    </div>

		    <div class="form-group">
		      <label for="exampleInputPassword1" class="form-label mt-4">Pickup Date</label>
		      <input type="date" name="fpdate" class="form-control" id="exampleInputPassword1" value="<?php echo $row['b_pickupdate'] ?>" required>
		    </div>

		    <div class="form-group">
		      <label for="exampleInputPassword1" class="form-label mt-4">Return Date</label>
		      <input type="date" name="frdate"class="form-control" id="exampleInputPassword1" value="<?php echo $row['b_returndate'] ?>" required>
		    </div>

		    <input type="hidden" name="fbid" value="<?php echo $row['b_id'] ?>" required>

		    <br>
		    <button type="submit" style="background-color: orange; color: black;" class="btn btn-primary">Modify now</button>
            <button type="reset" class="btn btn-outline-light">Reset</button>
		    
		  </fieldset>
		</form>

  <br></div>
</div>

</div>
<br><br>
<?php include 'footer.php';?>