<?php

include ('dbconnect.php'); 
$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user WHERE u_id = '$uid'";

$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

if ($row['u_type']==2){
  header('location:login.php?message0=please login again');
}
?>
<?php include 'cbssession.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
<head>
  <title>carsum.my</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/bootstrap.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="css/logo.png">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #212529;
   color: white;
   text-align: center;
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><img src="css/logo.png" style="width: 7%; height: auto;">arsum.my</a>    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor02">
    <ul class="navbar-nav me-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dashboard</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="dashboard.php">Main Page</a>
            <a class="dropdown-item" href="carlist.php">Edit Car List</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#" onclick="logOut()">&nbsp;Log out</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staffview.php">Booking List</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="staff.php">Receive List</a>
        </li>
      </ul>  
      <a class="btn btn-outline-info" role="button" href="#" onclick="logOut()">Log out</a>
    </div>
  </div>
</nav>

<script>
function logOut(){
  if(confirm("Do you want to log out?")){
    window.location.href = "logout.php";
  }
}
</script>

</body>
</html>