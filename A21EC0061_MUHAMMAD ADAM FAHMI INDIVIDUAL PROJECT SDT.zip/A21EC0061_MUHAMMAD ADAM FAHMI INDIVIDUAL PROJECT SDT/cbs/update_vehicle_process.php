<?php
include 'cbssession.php';
include("dbconnect.php");

if(!session_id())
{
    session_start();
}
$vreg = $_POST['vreg'];
$vtype = $_POST['vtype'];
$vmodel = $_POST['vmodel'];
$vyear = $_POST['vyear'];
$vprice = $_POST['vprice'];
$vmedia = $_FILES['my_media'];

if ($vtype != NULL) {
    $sql1 = "UPDATE tb_vehicle SET v_type = '$vtype' WHERE v_reg = '$vreg'";
    $result = mysqli_query($con, $sql1);
}
if ($vmodel != NULL) {
    $sql2 = "UPDATE tb_vehicle SET v_model = '$vmodel' WHERE v_reg = '$vreg'";
    $result = mysqli_query($con, $sql2);
}
if ($vyear != NULL) {
    $sql3 = "UPDATE tb_vehicle SET v_year = '$vyear' WHERE v_reg = '$vreg'";
    $result = mysqli_query($con, $sql3);
}
if ($vprice != NULL) {
    $sql5 = "UPDATE tb_vehicle SET v_price = '$vprice' WHERE v_reg = '$vreg'";
    $result = mysqli_query($con, $sql5);
}
if ($vmedia != NULL) {
    if (isset($_POST['submit']) && isset($_FILES['my_media'])) {
        include "dbconnect.php";
    
        echo "<pre>";
        print_r($_FILES['my_media']);
        echo "</pre>";
    
        $media_name = $_FILES['my_media']['name'];
        $media_size = $_FILES['my_media']['size'];
        $tmp_name = $_FILES['my_media']['tmp_name'];
        $error = $_FILES['my_media']['error'];
    
        if ($error == 0) {
            if ($media_size > 160000) {
                echo '<script>
                alert("File to big! Please upload a smaller size");
                window.location.href = "dashboard.php";
                </script>';
            }else {
                $media_ex = pathinfo($media_name, PATHINFO_EXTENSION);
                $media_ex_lc = strtolower($media_ex);
    
                $allowed_exs = array("jpg", "jpeg", "png"); 
    
                if (in_array($media_ex_lc, $allowed_exs)) {
                    $new_media_name = uniqid("IMG-", true).'.'.$media_ex_lc;
                    $media_upload_path = 'media/'.$new_media_name;
                    move_uploaded_file($tmp_name, $media_upload_path);
    
                    //UPDATE into Database
                    $sql = "UPDATE tb_vehicle SET v_media = '$new_media_name' WHERE v_reg = '$vreg'";
                    mysqli_query($con, $sql);
                    mysqli_close($con);
    
                }else {
                    echo '<script>
                alert("You cannot upload this type of file! Please upload only jpg, jpeg or png type of file");
                window.location.href = "dashboard.php";
                </script>';
                }
            }
        }else {
            echo '<script>
                alert("Car detail updated!");
                window.location.href = "dashboard.php";
                </script>';
        }
    
    }else {
        echo"ERROR FILE INPUT!";
    }
}

echo '<script>
alert("Car detail updated!");
window.location.href = "dashboard.php";
</script>'

?>