<?php
session_start();

//db connection
include("dbconnect.php");

//retrieve input
$fic = $_POST['fic'];
$fpwd = $_POST['fpwd'];

//this is to prevent SQL injection
$fic = mysqli_real_escape_string($con, $fic);
$fpwd = mysqli_real_escape_string($con, $fpwd);

//get user data from DB
$sql ="SELECT * FROM tb_user WHERE u_id ='$fic'";

//execute sql
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);
$count = mysqli_num_rows($result);

//login check
if($count == 1){ //user found

    //verify password
    if (password_verify($fpwd, $row['u_pwd'])) {
        //set session
        $_SESSION['u_id']=session_id();
        $_SESSION['uid']=$fic; //session variable only at particular page
        $_SESSION['u_name']=$row['u_name'];

        if($row['u_type']==1){  //staff
            header('location:dashboard.php');
        }
        else{   //customer
            header('location:customer.php');
        }
    } else {
        //display error
        echo '<script> alert("log in failed! Please use the correct user credentials"); 
        window.location.href = "index.php"; </script>';
    }
}
else{ //user not found
    //display error
    echo '<script> alert("log in failed! Please use the correct user credentials"); 
    window.location.href = "index.php"; </script>';
}

mysqli_close($con);

?>
