<?php 
include 'cbssession.php';
include 'headercustomer.php';
include ('dbconnect.php');

if(!session_id())
{
    session_start();
}

$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user 
        WHERE u_id='$uid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

?>

<div class="container">
<br>
<form method="POST" action="profile_process.php">
  <fieldset>
    <legend>Edit Profile Page</legend>
    
    <?php
    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">IC Number</label>';
      echo'<input type="text" class="form-control" name="fic" placeholder="'.$row['u_id'].'" readonly="">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Full Name</label>';
      echo'<input type="text" class="form-control" name="fname" placeholder="'.$row['u_name'].'">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Address</label>';
      echo'<textarea class="form-control" name="faddress" rows="3" placeholder="'.$row['u_address'].'"></textarea>';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Contact Number</label>';
      echo'<input type="text" class="form-control" name="fcontact" placeholder="'.$row['u_phone'].'">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">License No.</label>';
      echo'<input type="text" class="form-control" name="flino" placeholder="'.$row['u_lino'].'">';
    echo'</div>';

    ?>

</fieldset>

<br>

   <fieldset>
        <button type="submit" class="btn btn-primary">Update</button>
        <button type="reset" class="btn btn-outline-light">Reset</button>
  </fieldset>
</form>

<br><br><br>

</div>
<?php include 'footer.php'; ?>