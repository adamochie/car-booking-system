<?php
//Set DB parameterds
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_carbooksys";

//Create DB Connection
$con = mysqli_connect($servername,$username,$password,$dbname);


//Check DB Connection

?>