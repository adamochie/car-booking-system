<?php include 'headermain.php'; ?>

<style>
.masthead {
height: 100vh;
min-height: 500px;
background-position: center;
background-repeat: no-repeat;
background-size: cover;
}

</style>
<header class="d-flex masthead" style="background-image: url('css/pngwing.com.jpg');">
    <div class="container my-auto text-center">
        <h1 class="mb-1 fw-bold text-white">Fast and Reliable</h1>
        <h3 class="mb-5 fw-bold"><em>carsum. Rent sum more</em></h3><a class="btn btn-outline-warning btn-xl js-scroll-trigger" role="button" href="register.php">Sign up today!</a>
        <div class="overlay"></div>
    </div>
</header>

<body>
    <section>
        <div class="container py-4 py-xl-5">
            <div id="why_us" class="row gy-4 row-cols-1 row-cols-md-2 row-cols-lg-3">
                <div class="col">
                    <div class="card border-light border-1 d-flex justify-content-center p-4">
                        <div class="card-body">
                            <div class="bs-icon-lg bs-icon-rounded bs-icon-secondary d-flex flex-shrink-0 justify-content-center align-items-center d-inline-block mb-4 bs-icon"><svg class="icon icon-tabler icon-tabler-shield-check" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <path d="M9 12l2 2l4 -4"></path>
                                    <path d="M12 3a12 12 0 0 0 8.5 3a12 12 0 0 1 -8.5 15a12 12 0 0 1 -8.5 -15a12 12 0 0 0 8.5 -3"></path>
                                </svg></div>
                                
                            <div>
                                <h4 class="fw-bold">We provide Care.</h4>
                                <p class="text-muted">We provide top-notch care for your loved ones in the comfort of their own home.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-light border-1 d-flex justify-content-center p-4">
                        <div class="card-body">
                            <div class="bs-icon-lg bs-icon-rounded bs-icon-secondary d-flex flex-shrink-0 justify-content-center align-items-center d-inline-block mb-4 bs-icon"><svg class="icon icon-tabler icon-tabler-mood-smile" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="12" cy="12" r="9"></circle>
                                    <line x1="9" y1="10" x2="9.01" y2="10"></line>
                                    <line x1="15" y1="10" x2="15.01" y2="10"></line>
                                    <path d="M9.5 15a3.5 3.5 0 0 0 5 0"></path>
                                </svg></div>
                            <div>
                                <h4 class="fw-bold">We provide Best price</h4>
                                <p class="text-muted">Get the best deals on your favorite products at our website, where we strive to bring you the lowest prices possible.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-light border-1 d-flex justify-content-center p-4">
                        <div class="card-body">
                            <div class="bs-icon-lg bs-icon-rounded bs-icon-secondary d-flex flex-shrink-0 justify-content-center align-items-center d-inline-block mb-4 bs-icon"><svg class="icon icon-tabler icon-tabler-social" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="12" cy="5" r="2"></circle>
                                    <circle cx="5" cy="19" r="2"></circle>
                                    <circle cx="19" cy="19" r="2"></circle>
                                    <circle cx="12" cy="14" r="3"></circle>
                                    <line x1="12" y1="7" x2="12" y2="11"></line>
                                    <line x1="6.7" y1="17.8" x2="9.5" y2="15.8"></line>
                                    <line x1="17.3" y1="17.8" x2="14.5" y2="15.8"></line>
                                </svg></div>
                            <div>
                                <h4 class="fw-bold">We provide Uniqueness</h4>
                                <p class="text-muted">Discover one-of-a-kind products and experiences on our website, where uniqueness is at the forefront of everything we offer.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="py-4 py-xl-5">
        <div class="container">
            <div class="bg-primary border rounded border-0 border-primary overflow-hidden">
                <div class="row g-0">
                    <div class="col-md-6 d-flex flex-column justify-content-center">
                        <div class="text-white p-4 p-md-5">
                            <h2 class="fw-bold text-white mb-3">We Are Car Lovers Too!</h2>
                            <p class="mb-4">We are the only other place (besides home) where you can leave your car keys behind safely. We will treat your car like our own!</p>
                            <div class="my-3"><a class="btn btn-outline-warning mt-2" role="button" href="register.php">Book appointment</a></div>
                        </div>
                    </div>
                    <div class="col-md-6 order-first order-md-last" style="min-height: 250px;"><img class="w-100 h-100 fit-contain pt-5 pt-md-0" src="css/car-lovers-v1.2.png" /></div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-5">
        <div class="container py-4 py-xl-5">
            <div class="row mb-5">
                <div class="col-md-8 col-xl-6 text-center mx-auto">
                    <h2 class="display-6 fw-bold mb-4">Book quality services<br />with our <span class="underline">amazing plans now</span></h2>
                    <p class="text-muted">Here’s a quick guide on the type of service your car may need. Still unsure? Get in touch and we’ll help you figure it out!</p>
                </div>
            </div>
            <div class="row gy-4 row-cols-1 row-cols-md-2 row-cols-lg-3">
                <div class="col">
                    <div class="card border-0 h-100">
                        <div class="card-body d-flex flex-column justify-content-between p-4">
                            <div>
                                <h6 class="fw-bold text-muted">Essential</h6>
                                <h4 class="display-5 fw-bold mb-4">RM98</h4>
                                <ul class="list-unstyled">
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Engine oil replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Windshield washer replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Oil filter replacement</span></li>
                                </ul>
                            </div><a class="btn btn-primary" role="button" href="register.php">Be a member now</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-warning border-2 h-100">
                        <div class="card-body d-flex flex-column justify-content-between p-4"><span class="badge bg-warning position-absolute top-0 end-0 rounded-bottom-left text-uppercase text-primary">Most Popular</span>
                            <div>
                                <h6 class="fw-bold text-muted">Standard</h6>
                                <h4 class="display-5 fw-bold mb-4">RM138</h4>
                                <ul class="list-unstyled">
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Windshield washer replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Air filter replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Brake fluid replacement</span></li>
                                </ul>
                            </div><a class="btn btn-primary" role="button" href="register.php">Be a member now</a>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="card border-0 h-100">
                        <div class="card-body d-flex flex-column justify-content-between p-4">
                            <div class="pb-4">
                                <h6 class="fw-bold text-muted">Comprehensive</h6>
                                <h4 class="display-5 fw-bold mb-4">RM288</h4>
                                <ul class="list-unstyled">
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Windshield washer replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Coolant replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Auto/manual transmission oil replacement</span></li>
                                    <li class="d-flex mb-2"><span class="bs-icon-xs bs-icon-rounded bs-icon me-2"><svg class="icon icon-tabler icon-tabler-check fs-5 text-primary" xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M5 12l5 5l10 -10"></path>
                                            </svg></span><span>Engine oil replacement</span></li>
                                </ul>
                            </div><a class="btn btn-primary" role="button" href="register.php">Be a member now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="py-4 py-xl-5">
        <div id="contacts" class="container">
            <div class="text-white bg-primary border rounded border-0 border-primary d-flex flex-column justify-content-between flex-lg-row p-4 p-md-5">
                <div class="pb-2 pb-lg-1">
                    <h2 class="fw-bold text-warning mb-2">Not sure which plan suits you?</h2>
                    <p class="mb-0">Call this number: 016 - 760 3218 (CARSUM Johor)</p>
                </div>
            </div>
        </div>
    </section>
</body>

<?php include 'footer.php'; ?>
