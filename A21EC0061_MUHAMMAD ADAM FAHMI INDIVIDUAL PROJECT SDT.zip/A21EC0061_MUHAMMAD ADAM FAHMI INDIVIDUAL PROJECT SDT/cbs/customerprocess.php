<?php
include 'cbssession.php';
if(!session_id()){
    session_start();
}

include("dbconnect.php");

$fic = $_SESSION['uid'];
$fvec = $_POST['fvec'];
$fpdate = $_POST['fpdate'];
$frdate = $_POST['frdate'];

//calculate number of days
$pickup = date('Y-m-d H:i:s', strtotime($fpdate));
$return = date('Y-m-d H:i:s', strtotime($frdate));
$daydiff = abs(strtotime($frdate) - strtotime($fpdate)); //or abs($frdate - $fpdate);

//calculate number days rent
$daynum = $daydiff/(60*60*24);

$sqlprice = "SELECT v_price FROM tb_vehicle WHERE v_reg = '$fvec'";
$resultprice = mysqli_query($con, $sqlprice);
$rowprice = mysqli_fetch_array($resultprice);

//calculate total price
$totalprice = $daynum*($rowprice['v_price']);

//record(insert) new booking to DB
if(isset($_POST['fpdate']) && isset($_POST['frdate'])){
    $pickup_date = strtotime($_POST['fpdate']);
    $return_date = strtotime($_POST['frdate']);
    if($return_date <= $pickup_date){
        echo '<script> alert("Sorry, the return date entered are before the pick up date")
        window.location.href = "customer.php";
        </script>';

    } else {
        $sql = "INSERT INTO tb_booking (b_customer, b_vehicle, b_pickupdate, b_returndate, b_totalprice, b_status)
                VALUES ('$fic','$fvec','$fpdate','$frdate','$totalprice', '1')";
         echo '<script> alert("Your book are sent!")
         window.location.href = "customermanage.php";
         </script>';

        mysqli_query($con,$sql);
        mysqli_close($con);

    }
}
?>