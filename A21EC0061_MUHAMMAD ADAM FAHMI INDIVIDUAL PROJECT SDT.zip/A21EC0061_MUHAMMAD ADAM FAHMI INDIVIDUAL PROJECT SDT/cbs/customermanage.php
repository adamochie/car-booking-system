<?php

include 'cbssession.php';
if(!session_id()){
    session_start();
}

include 'headercustomer.php'; 
include ('dbconnect.php');

$fic = $_SESSION['uid'];

//retrieve individual booking
$sql = "SELECT * FROM tb_booking
        LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
        LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
        WHERE b_customer = '$fic'";

$result = mysqli_query($con,$sql);
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="container">
    
    <h3><br><br></h3>
    <div class="row">
        <div class="col-md-4 col-xxl-7">
            <h2 style="width: 343px;">Your Booking List</h2>
        </div>
        <div class="col-md-4 d-flex justify-content-end align-self-start">
        <form method="GET" action="">
            <i class="fa fa-search"></i><input class="form-control me-sm-2" type="text" name="search" placeholder="Enter booking ID">
        </form>
        </div>
    </div>
<br><br>

<?php
if(isset($_GET['search'])){
    $search_id = $_GET['search'];
    $sql = "SELECT * FROM tb_booking
            LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
            LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
            WHERE b_customer = '$fic' AND b_id = '$search_id'";
    $result = mysqli_query($con,$sql);
} else {
    $sql = "SELECT * FROM tb_booking
            LEFT JOIN tb_vehicle ON tb_booking.b_vehicle = tb_vehicle.v_reg
            LEFT JOIN tb_status ON tb_booking.b_status = tb_status.s_id
            WHERE b_customer = '$fic'";
    $result = mysqli_query($con,$sql);
}
?>

    <table class="table table-hover">
    <thead>
        <tr>
            <th scope="col">Booking ID</th>
            <th scope="col">Vehicle</th>
            <th scope="col">Pickup date</th>
            <th scope="col">Return date</th>
            <th scope="col">Total price</th>
            <th scope="col">Status</th>
            <th scope="col">Operation</th>
        </tr>
    </thead>
    <tbody>

<?php
    while($row = mysqli_fetch_array($result)){
        echo '<tr>';
        echo "<td>".$row['b_id']."</td>";
        echo "<td>".$row['v_model']."</td>";
        echo "<td>".$row['b_pickupdate']."</td>";
        echo "<td>".$row['b_returndate']."</td>";
        echo "<td>".$row['b_totalprice']."</td>";
        echo "<td>".$row['s_desc']."</td>"; //letak non tb_booking variable by JOIN ON syntax
        echo "<td>";
            echo"<a href= 'customermodify.php?id=" .$row['b_id']." 'class= 'btn btn-warning'>Modify</a>";
            echo"<a href= 'customercancel.php?id=" .$row['b_id']." 'class= 'btn btn-danger'>Cancel</a>";
        echo '</tr>';
    }
?>

    </tbody>
    </table>
</div>


<?php include 'footer.php'; ?>


