<?php 
include 'cbssession.php';
include 'headerstaff.php';
include ('dbconnect.php');

if(!session_id())
{
    session_start();
}

if(isset($_GET['id']))
{
	$carid = $_GET['id'];
}

$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_vehicle 
        WHERE v_reg='$carid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

?>

<div class="container">
<br>
<form method="POST" action="update_vehicle_process.php" enctype="multipart/form-data">
  <fieldset>
    
    <?php
    echo '<legend>Edit Vehicle ['.$row['v_reg'].'] Details</legend>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Vehicle Registration</label>';
      echo'<input type="text" class="form-control" name="vreg" placeholder="'.$row['v_reg'].'" readonly="" value="'.$row['v_reg'].'">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Vehicle Type</label>';
      echo'<input type="text" class="form-control" name="vtype" placeholder="'.$row['v_type'].'">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Vehicle Model</label>';
      echo'<input type="text" class="form-control" name="vmodel" placeholder="'.$row['v_model'].'">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Vehicle Year</label>';
      echo'<input type="text" class="form-control" name="vyear" placeholder="'.$row['v_year'].'">';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Price Rent</label>';
      echo'<input type="text" class="form-control" name="vprice" placeholder="RM'.$row['v_price'].'">';
    echo'</div>';
    ?>

</fieldset>

<br>
  <fieldset>
        <div class="form-group">
        <label for="exampleInputPassword1" class="form-label mt-4">Car Media</label>
        <input type="file" class="form-control" name="my_media" id="my_media">
        <br>
        <input type="submit" name="submit" value="Update" class="btn btn-primary">
        <button type="reset" class="btn btn-outline-light">Reset</button>
        </div>
    </fieldset>
</form>

<br><br><br>

</div>
<?php include 'footer.php'; ?>