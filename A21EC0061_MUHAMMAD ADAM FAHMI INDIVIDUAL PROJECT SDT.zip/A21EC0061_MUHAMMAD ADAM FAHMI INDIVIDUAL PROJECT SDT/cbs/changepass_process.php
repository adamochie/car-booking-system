<?php
include 'cbssession.php';
include("dbconnect.php");

if(!session_id())
{
    session_start();
}

$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user 
        WHERE u_id='$uid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);


$fpwd = $_POST['fpwd'];
$fpwd2 = $_POST['fpwd2'];

if (password_verify($fpwd, $row['u_pwd'])) {

    $password_hash = password_hash($fpwd2, PASSWORD_DEFAULT);
    $sql2 = "UPDATE tb_user SET u_pwd = '$password_hash' WHERE u_id = '$uid'";
    $result = mysqli_query($con, $sql2);

    echo '<script>
    alert("New password created successfully!");
    window.location.href = "customer.php";
    </script>';
}
else{
    echo '<script>
    alert("Wrong password entered! Please reenter the correct password");
    window.location.href = "changepass.php";
    </script>';
}

echo '<script>
alert("Profile updated!");
window.location.href = "profile.php";
</script>'

?>