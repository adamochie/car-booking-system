<?php 
include 'cbssession.php';
include 'headercustomer.php';
include ('dbconnect.php');

if(!session_id())
{
    session_start();
}

$uid = $_SESSION['uid'];
$sql = "SELECT * FROM tb_user 
        WHERE u_id='$uid'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

?>

<div class="container">
<br>
<form method="POST" action="changepass_process.php">
  <fieldset>
    <legend>Modify Password</legend>
    
    <?php

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">Change Password</label>';
      echo'<input type="password" class="form-control" name="fpwd" placeholder="Enter old password" required>';
    echo'</div>';

    echo'<div class="form-group">';
      echo'<label class="form-label mt-4">New Password</label>';
      echo'<input type="password" class="form-control" name="fpwd2" placeholder="Enter new password" required>';
    echo'</div>';
    ?>

</fieldset>

<br>

   <fieldset>
        <button type="submit" class="btn btn-primary">Modify</button>
        <button type="reset" class="btn btn-outline-light">Reset</button>
  </fieldset>
</form>

<br><br><br>

</div>
<?php include 'footer.php'; ?>