<?php include 'headermain.php'; ?>

<br>

<div class ="container">
<form method="POST" action="loginprocess.php">
  <fieldset>
    <legend>Log in form</legend>

    <div class="form-group">
      <label for="exampleInputEmail1" class="form-label mt-4">IC Number</label>
      <input type="text" name="fic" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="XXXXXX-XX-XXXX" required>
    </div>

    <div class="form-group">
      <label for="exampleInputPassword1" class="form-label mt-4"> Password</label>
      <input type="password" name='fpwd' class="form-control" id="exampleInputPassword1" placeholder="Enter password" required>
    </div>

  </fieldset>

<br><br><br>

   <fieldset>
        <button type="submit" class="btn btn-primary">Submit</button>
  </fieldset>
</form>

<br><br><br>

</div>

<?php include 'footer.php'; ?>
