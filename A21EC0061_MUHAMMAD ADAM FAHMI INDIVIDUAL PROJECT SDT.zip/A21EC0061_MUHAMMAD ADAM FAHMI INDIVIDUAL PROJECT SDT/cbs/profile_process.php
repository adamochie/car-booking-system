<?php
include("dbconnect.php");
include 'cbssession.php';

if(!session_id())
{
    session_start();
}

$uid = $_SESSION['uid'];
$fic = $_POST['fic'];
$faddress = $_POST['faddress'];
$fname = $_POST['fname'];
$fcontact = $_POST['fcontact'];
$flino = $_POST['flino'];

//if ($fic != NULL) {
  //  $sql1 = "UPDATE tb_user SET u_id = '$fic' WHERE u_id = '$uid'";
    //$result = mysqli_query($con, $sql1);
//}
if ($fname != NULL) {
    $sql2 = "UPDATE tb_user SET u_name = '$fname' WHERE u_id = '$uid'";
    $result = mysqli_query($con, $sql2);
}
if ($faddress != NULL) {
    $sql3 = "UPDATE tb_user SET u_address = '$faddress' WHERE u_id = '$uid'";
    $result = mysqli_query($con, $sql3);
}
if ($fcontact != NULL) {
    $sql5 = "UPDATE tb_user SET u_phone = '$fcontact' WHERE u_id = '$uid'";
    $result = mysqli_query($con, $sql5);
}
if ($flino != NULL) {
    $sql6 = "UPDATE tb_user SET u_lino = '$flino' WHERE u_id = '$uid'";
    $result = mysqli_query($con, $sql6);
}
echo '<script>
alert("Profile updated!");
window.location.href = "profile.php";
</script>'

?>