<header class="masthead" style="background-image: url('header-bg.jpg');">
    <div class="container">
        <div class="intro-text">
            <div class="intro-lead-in"><span>Welcome To Our Studio!</span></div>
            <div class="intro-heading text-uppercase"><span>It&#39;s Nice To Meet You</span></div><a class="btn btn-primary btn-xl text-uppercase" role="button" href="#services">Tell mE more</a>
        </div>
    </div>
</header>